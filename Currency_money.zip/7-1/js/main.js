let elExchangeForm=document.querySelector(".exchange_form");
let elUserInput=document.querySelector(".user_input");
let elOldSelect=document.querySelector(".old_select_rate");
let elNewSelect=document.querySelector(".new_select_rate");
let elResult=document.querySelector(".result");

elExchangeForm.addEventListener('submit', function(event){
    event.preventDefault();
    let inputValue=elUserInput.value;
    let oldSelectValue=elOldSelect.value;
    let newSelectValue=elNewSelect.value;
    let resultValue=0;
    if(oldSelectValue=='uzs') {
        let nowUSD=11000;
        let nowEURO=10000;
        let nowRUBL=1000;
        if(newSelectValue=='uzs') {
            resultValue=parseInt(inputValue);
        }else if(newSelectValue=='usd') {
            resultValue=parseInt(inputValue)/nowUSD;
        } else if(newSelectValue=='euro') {
            resultValue=parseInt(inputValue)/nowEURO;
        } else {
            resultValue=parseInt(inputValue)/nowRUBL;
        }
    } else if(oldSelectValue=='usd') {
        let nowUZS=11000;
        let nowEURO=1.1;
        let nowRUBL=11;
        if(newSelectValue=='usd') {
            resultValue=parseInt(inputValue);
        } else if(newSelectValue=='uzs') {
            resultValue=parseInt(inputValue)*nowUZS;
        } else if(newSelectValue=='euro') {
            resultValue=parseInt(inputValue)*nowEURO;
        } else {
            resultValue=parseInt(inputValue)*nowRUBL;
        }
    } else if(oldSelectValue=='euro') {
        let nowUZS=10000;
        let nowUSD=1.1;
        let nowRUBL=100;
        if(newSelectValue=='euro') {
            resultValue=parseInt(inputValue);
        }else if(newSelectValue=='uzs') {
            resultValue=parseInt(inputValue)*nowUZS;
        } else if(newSelectValue=='usd') {
            resultValue=parseInt(inputValue)/nowUSD;
        } else {
            resultValue=parseInt(inputValue)*nowRUBL;
        }
    } else {
        let nowUZS=1000;
        let nowUSD=11;
        let nowEURO=10;
        if(newSelectValue=='rubl') {
            resultValue=parseInt(inputValue);
        }else if(newSelectValue=='uzs') {
            resultValue=parseInt(inputValue)*nowUZS;
        } else if(newSelectValue=='usd') {
            resultValue=parseInt(inputValue)/nowUSD;
        } else {
            resultValue=parseInt(inputValue)/nowEURO;
        }
    }
    elResult.textContent=resultValue;
});